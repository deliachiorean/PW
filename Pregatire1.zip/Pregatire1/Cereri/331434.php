<?php
echo file_get_contents("../login.php");
?>