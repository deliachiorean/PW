<?php
    echo "Nu sunteti logat!";
?>