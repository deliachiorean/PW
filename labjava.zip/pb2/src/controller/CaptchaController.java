package controller;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageProducer;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

public class CaptchaController extends HttpServlet {

    private String captchaCode = "";
    //magic happens here
    protected void processRequest(HttpServletRequest request,
                                  HttpServletResponse response)
            throws ServletException, IOException {

        //width and height of the image
        int width = 150;
        int height = 50;

        //possible captcha codes
        char data[][] = {
                { 'u', 'b', 'b', 's', 'u', 'k', 's' },
                { 'l', 'i', 'n', 'u', 'x' },
                { 'f', 'r', 'e', 'e', 'b', 's', 'd' },
                { 'u', 'b', 'u', 'n', 't', 'u' },
                { 'j', 'e', 'e' },
                { '1', '2', 'n', 'i', 'c', 'u'},
                { 'x', 'd', 'd' }
        };

        //create image
        BufferedImage bufferedImage = new BufferedImage(width, height,
                BufferedImage.TYPE_INT_RGB);

        Graphics2D g2d = bufferedImage.createGraphics();
        //set the font
        Font font = new Font("Georgia", Font.BOLD, 18);
        g2d.setFont(font);

        //idk what this is
        RenderingHints rh = new RenderingHints(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        rh.put(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);

        g2d.setRenderingHints(rh);

        //set colors
        g2d.setColor(new Color(0, 0, 0));
        g2d.fillRect(0, 0, width, height);

        g2d.setColor(new Color(255, 255, 255));

        //get a random captcha code
        Random r = new Random();
        int index = Math.abs(r.nextInt()) % 6;

        String captcha = String.copyValueOf(data[index]);
        captchaCode = captcha;
        //send the captcha
        request.getSession().setAttribute("captcha", captcha);

        int x = 0;
        int y = 0;

        //draw captcha
        for (int i = 0; i < data[index].length; i++) {
            x += 10 + (Math.abs(r.nextInt()) % 15);
            y = 20 + Math.abs(r.nextInt()) % 20;
            g2d.drawChars(data[index], i, 1, x, y);
        }

        g2d.dispose();

        response.setContentType("image/png");
        OutputStream os = response.getOutputStream();
        ImageIO.write(bufferedImage, "png", os);
        os.close();
    }

    //get the captcha code
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    //checks the captcha code
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {
        //check if captcha matches
        String captchaFromInput = request.getParameter("captcha");
        RequestDispatcher rd = null;
        if (captchaFromInput.equals(this.captchaCode)) {
            //is good
            rd = request.getRequestDispatcher("./success.jsp");
        } else {
            rd = request.getRequestDispatcher("./error.jsp");
        }
        rd.forward(request, response);
    }
}
