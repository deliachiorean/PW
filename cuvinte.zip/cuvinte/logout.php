<?php
/**
 * Created by PhpStorm.
 * User: Coste Claudia Ioana
 * Date: 6/16/2018
 * Time: 11:39 AM
 */
session_start();
if (isset($_SESSION['username'])) {
    session_unset();
    session_destroy();
    header("Location: adminIndex.html");
} else {
    echo "Nu sunteti logat!!!";
}

?>