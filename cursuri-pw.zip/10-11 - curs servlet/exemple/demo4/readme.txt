Ion este un prost. Acest prost e cel mai mare prost din zona.
