Documentatie JavaScript (lectura obligatorie): http://www.w3schools.com/js/default.asp
