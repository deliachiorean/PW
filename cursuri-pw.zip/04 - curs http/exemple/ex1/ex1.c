#include <stdio.h>

int main() {
  printf("Content-type: text/html\n");
  printf("\n");
  printf("Hello world!");
}
