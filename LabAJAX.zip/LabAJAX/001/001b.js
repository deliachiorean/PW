function afisarePlecari() {
    let url = "001.php?oras=" + $("#lista1 option:selected").text();

    $.ajax({
        url: url, async: true, success: function (result) {
            $("#lista2").html(result);
        }
    });
}

function stateChanged() {
    if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
        $("#lista2").html(xmlhttp.responseText);
    }
}