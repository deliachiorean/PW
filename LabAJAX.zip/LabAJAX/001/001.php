<?php
    $orasPlecare = $_GET["oras"];

    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "labajax";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM t001";

    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $stmt->bind_result($plecare, $sosire);

    while($stmt->fetch()){
        if ($plecare === $orasPlecare)
            echo "<option>" . $sosire . "</option>";
    }

    $stmt->close();
    $conn->close();
?>